const Settings = () => {
    return <div>Settings Page</div>;
  };
  
  export default Settings;