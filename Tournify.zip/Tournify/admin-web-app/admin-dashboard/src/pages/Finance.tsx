function Finance() {
    return <h1>Finance Page</h1>
  }
  
  export default Finance
  