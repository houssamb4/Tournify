function Moderation() {
    return <h1>Moderation Page</h1>
  }
  
  export default Moderation
  